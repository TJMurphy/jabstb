#' 'ggfittext': provides a 'ggplot2' geom to fit text inside a box.
#'
#' This package provides only one function, \code{geom_fit_text}.
#'
#' @docType package
#' @name ggfittext
NULL
