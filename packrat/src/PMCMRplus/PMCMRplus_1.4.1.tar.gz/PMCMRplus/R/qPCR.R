#' @name qPCR
#' @docType data
#' @title
#'  qPCR Curve Analysis Methods
#' @description
#'  The data set contains 4 classifiers (blocks), i.e.
#'  bias, linearity, precision and resolution, for 11
#'  different qPCR analysis methods. The null hypothesis
#'  is that there is no preferred ranking of the method results
#'  per gene for the performance parameters analyzed.
#'  The rank scores were obtained by averaging results
#'  across a large set of 69 genes in a biomarker data file.
#'
#' @format
#'  A data frame with 4 observations on the following 11 variables.
#'  \describe{
#'    \item{Cy0}{a numeric vector}
#'    \item{LinRegPCR}{a numeric vector}
#'    \item{Standard_Cq}{a numeric vector}
#'    \item{PCR_Miner}{a numeric vector}
#'    \item{MAK2}{a numeric vector}
#'    \item{LRE_E100}{a numeric vector}
#'    \item{5PSM}{a numeric vector}
#'    \item{DART}{a numeric vector}
#'    \item{FPLM}{a numeric vector}
#'    \item{LRE_Emax}{a numeric vector}
#'    \item{FPK_PCR}{a numeric vector}
#'  }
#'
#' @source
#'  Data were taken from Table 2 of Ruijter et al. (2013, p. 38).
#'  See also Eisinga et al. (2017, pp. 14--15).
#'
#' @references
#'  Eisinga, R., Heskes, T., Pelzer, B., Te Grotenhuis, M. (2017)
#'  Exact p-values for pairwise comparison of Friedman rank sums,
#'  with application to comparing classifiers.
#'  \emph{BMC Bioinformatics}, 18:68.
#'
#'  Ruijter, J. M. et al. (2013) Evaluation of qPCR curve analysis
#'  methods for reliable biomarker discovery: Bias, resolution,
#'  precision, and implications, \emph{Methods} \bold{59}, 32--46.
#' @keywords datasets
NULL

