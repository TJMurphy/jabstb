"ES.w1" <-
function(P0,P1){
sqrt(sum((P1-P0)^2/P0))
}

