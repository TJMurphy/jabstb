library(testthat)
library(treemapify)

test_check("treemapify")
